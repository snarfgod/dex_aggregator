import { ethers } from 'ethers'

import {
  setProvider,
  setNetwork,
  setAccount
} from './reducers/provider'

import {
  setAggregatorContract,
  setRate,
  setAMM,
  balancesLoaded
} from './reducers/aggregator'

import AGGREGATOR_ABI from '../abis/Aggregator.json';

import config from '../config.json';
import WETH_ABI from '../abis/WETH.json';
import DAI_ABI from '../abis/DAI.json';
import MATIC_ABI from '../abis/MATIC.json';

export const loadProvider = (dispatch) => {
  const provider = new ethers.providers.Web3Provider(window.ethereum)
  dispatch(setProvider(provider))

  return provider
}

export const loadNetwork = async (provider, dispatch) => {
  const { chainId } = await provider.getNetwork()
  dispatch(setNetwork(chainId))

  return chainId
}

export const loadAccount = async (dispatch) => {
  const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' })
  const account = ethers.utils.getAddress(accounts[0])
  dispatch(setAccount(account))

  return account
}

// Load contracts
export const loadAggregatorContract = async (provider, chainId, dispatch) => {
  const aggregator = new ethers.Contract(config[chainId].aggregator.address, AGGREGATOR_ABI, provider)

  dispatch(setAggregatorContract(aggregator))

  return aggregator
}

//Get rate from best AMM
export const getBestRate = async (dispatch, aggregator, inputToken, outputToken, amount) => {
  const [rate, AMM] = await aggregator.calculateBestRate(inputToken, outputToken, amount)
  dispatch(setRate(ethers.utils.formatUnits(rate, 18)))
  dispatch(setAMM(AMM))
  return [rate, AMM]
}

// Get Balances
export const loadBalances = async (dispatch, inputToken, outputToken, account) => {
  const balance1 = await inputToken.balanceOf(account)
  const balance2 = await outputToken.balanceOf(account)


  dispatch(balancesLoaded([balance1, balance2]))
  return balance1, balance2
}

